title: 使用阿里云maxcompute sql随机从查询数据中抽取n条样本
date: '2019-09-27 14:26:54'
updated: '2019-09-27 15:15:07'
tags: [sql]
permalink: /articles/2019/09/27/1569565614842.html
---
近些年大数据发展迅速，大数据生态圈也越来越丰富。使用sql进行数据分析时有个常用的组件叫 [HIVE](https://hive.apache.org/) ，而阿里云则提供了类似HIVE功能的商业云服务，称为 [maxcompute](https://help.aliyun.com/document_detail/27800.html) 。

今天记录一下使用maxcompute sql从数据中随机抽取n条样本的方法。

假设有数据如下：

id|name
--|--
1|张三
2|李四
3|王五
4|龙傲天
5|刘斩仙
6|赵日天

我们想随机从上表中抽取3条数据，应该怎么写？

假设表名为`tmp_table`:

```sql
select id,name from tmp_table
order by rand() limit 3
```

这样就能够从表中随机抽取3条数据了。假设我们运行的结果如下：

```
1 张三
3 王五
4 龙傲天
```

你可以尝试反复运行上面的sql，然后就会发现，每次运行的结果都是相同的，随机抽取数据都是上面给的3条。为什么呢？

从sql来理解，上面的语句相当于生成了一个随机序列，每条记录都分配了一个随机值，然后所有记录按照随机值排序，从排序结果中取前3条，以此达到随机选择的目的。

然后rand()方法产生随机数需要使用随机数种子，相同随机数种子产生的随机数永远都是一样的。当不传递随机数种子时，函数将使用默认的固定随机数种子，所以无论运行多少次，产生的随机数都是固定的。

那要怎么解决这个问题呢？传入每次都会变化的随机数种子就可以啦。比如选择当前的时间戳：

```sql
select id,name from tmp_table
order by rand(unix_timestamp()) limit 3
```

现在，每次运行的结果都不一样咯，搞定！



参考文章：

[MaxCompute SQL随机抽取N行数据](https://yq.aliyun.com/users/ki4r6p45u3y6m)
