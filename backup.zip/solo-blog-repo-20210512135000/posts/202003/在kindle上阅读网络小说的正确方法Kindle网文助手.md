title: 在kindle上阅读网络小说的正确方法——Kindle网文助手
date: '2020-03-11 17:21:22'
updated: '2020-03-11 17:22:58'
tags: [python, 爬虫, web]
permalink: /articles/2020/03/11/1583918482378.html
---
# 起源

kindle是个好东西啊，如果长时间阅读的话，kindle的体验远胜于手机、电脑。亚马逊上有丰富的kindle电子书资源，但很遗憾，亚马逊上没有网络小说。手机起点又不支持推送到kindle阅读，如果偶尔先看看网文的话，那是真的有点淡疼……

于是，就抽出几天零碎时间，写了个简单的小工具，我把它叫做Kindle网文助手。支持从网络上下载网络小说，并推送到 kindle 上阅读。

请注意，此项目不提倡盗版阅读，只因为手机起点看书费眼，也没有推送到 kindle 的途径，才萌生想法编写此项目。没有直接爬起点网站，是嫌起点反爬太多，太麻烦了（毕竟起点要面对那么多盗版网站的爬虫）。网文作者写书不易，有能力的朋友尽量订阅支持一下。

**推荐如下操作：** 选择一本想看的书 xxx => 打开起点，找到 xxx => 自动订阅 => 打开 kindle 网文助手，缓存 xxx => 推送到 kindle 阅读

如果真的没有闲钱，也请注册一下起点的账号，加一下收藏，投一下免费的推荐票，为你喜欢的小说点赞。写手不易，且行且珍惜。

随便写写的极简版本，比较简陋，凑合着用吧，等待后期迭代。

**此项目只用于技术交流，请勿用于任何商业用途，否则后果自负！**

# 开发环境


项目结构可以分为三个部分，前端、后端和爬虫。前端主要提供用户交互功能，后端提供api服务，爬虫提供小说抓取支持。

关于前端：

为了快速成型，前端选择了使用 Vue.js + Element UI 实现。没有刻意去美化前端，毕竟自己用，功能齐全，操作方便就行。考虑到有时候会用手机打开助手，所以对页面做了响应式布局处理，保证在不同分辨率的屏幕上，页面都能正常显示。

关于后端：

编程语言使用Python3.7，Web框架选择Flask，我不太喜欢用Django，太重量型了，Flask更轻便，想要什么加什么，用起来更舒服。ORM选择了sqlalchemy。生产环境部署选择gunicorn + gevent，毕竟只是自己用，就没用nginx代理。

关于爬虫：

跟第二点考虑相同，不想把项目搞得太复杂，爬虫使用requests+beautifulsoup4实现，没有做并发。没做并发的原因有两点：①反正是放在后台跑，慢点没关系②出于稳定性考虑，频率高可能会导致被ban的几率提升③会使项目更复杂，要加入新的组件。关于第三点，我在付出与收益上权衡再三，决定还是不做并发——对使用体验没有多大影响，觉得没啥必要。后面在实际使用中看是否有加入并发的必要。

另外，为了最小可用模型的开发速度，目前助手里面只加了一个网站的爬虫，但基本上也够用了。后续会增加更多网站爬虫支持（可能？看懒不懒吧……）。

如果想自己增加爬虫的话，也很简单，我提前留好了接口。只需要在`src/spiders/spider.py` 中添加相关的爬虫类，继承 `BaseSpider` 类并实现相关接口即可。程序会自动解析并加载所有爬虫。

关于数据库：

MySQL 5.7。虽然想让项目尽量简单，但思来想去，数据库还是没法省略掉的。

关于消息队列：

这里消息队列主要用于后端与爬虫之间的通信，选择的rabbitmq。有考虑过redis，毕竟redis+scrapy还是很舒服的。但觉得redis有点太重了，遂放弃。同理，考虑过celery做异步，也放弃了。

# 使用方法


这个就直接参考GitHub吧，地址如下:

[WebFictionForKindle](https://github.com/AaronJny/WebFictionForKindle) : https://github.com/AaronJny/WebFictionForKindle

# 简单演示

1.打开浏览器，访问主页，默认 [http://localhost:7777/](http://localhost:7777/),根据个人情况修改：

[![1](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/1.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/1.png)

2.当前没有缓存任何小说，我们搜索一下：

[![2](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/2.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/2.png)

3.只搜索出来一个结果。看一下基本信息，这就是我需要的，所以我点击 `导入书籍`。可以看到，书籍被加入到书架中，并开始缓存所有章节：

[![3](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/3.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/3.png)

4.小说的缓存进度会自动刷新，每 5 秒刷新一次：

[![4](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/4.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/4.png)

5.在小说缓存的过程中，我们看一下其他功能。如果需要推送小说到 kindle，还需要配置邮箱信息。点击 `配置邮箱` 按钮：

[![5](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/5.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/5.png)

按照要求填写各配置项，并提交。关于亚马逊的〖发送至 Kindle〗的更多信息，可以参考[了解如何使用〖发送至 Kindle〗电子邮箱](https://www.amazon.cn/gp/help/customer/display.html/ref=hp_left_v4_sib?ie=UTF8&nodeId=G7NECT4B4ZWHQ8WV)系列文档。

6.`配置爬虫` 按钮可以对使用的爬虫进行管理，初始版本只加入了一个爬虫，后面会加入更多爬虫：

[![6-1](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/6-1.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/6-1.png)

[![6-2](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/6-2.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/6-2.png)

7.小说已经缓存完成了，点击 `更新` 按钮，会检测小说是否有新增章节，并自动缓存新增章节。

[![7](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/7.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/7.png)

8.`导出` 按钮，可以导出小说的 txt 文件到本地：

[![8-1](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/8-1.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/8-1.png)

[![8-2](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/8-2.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/8-2.png)

我把服务跑在一个远程小主机上了，配置很差，带宽只有 1m，所以下载到本地有点慢。

[![8-3](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/8-3.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/8-3.png)

9.更多时候，我们并不需要把 txt 导出到本地。点击 `推送` 按钮，可以直接远程生成 txt 文件并推送到 kindle 上：

[![9-1](https://github.com/AaronJny/WebFictionForKindle/raw/master/images/9-1.png)](https://github.com/AaronJny/WebFictionForKindle/blob/master/images/9-1.png)

请注意，亚马逊的文档推送服务有一定的延迟，打开 kindle 的网络连接，耐心等待一下，就能在 kindle 上看到这本小说。

大概就是这样吧，`删除` 就不用演示了。

# 结语

为了自己方便而编写的小项目，不知道对你是否有帮助呢？

如果喜欢这篇文章的话，麻烦给个赞吧～谢谢大佬～

**再次声明，此项目不提倡盗版阅读，网文作者写书不易，有能力的朋友请尽量订阅支持一下正版。如果真的没有闲钱，也请注册一下起点的账号，加一下收藏，投一下免费的推荐票，为你喜欢的小说点赞。写手不易，且行且珍惜。此项目只用于技术交流，禁止用于任何商业用途，否则后果自负！**




