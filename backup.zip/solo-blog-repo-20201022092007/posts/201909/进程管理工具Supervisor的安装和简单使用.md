title: 进程管理工具Supervisor的安装和简单使用
date: '2019-09-30 15:51:04'
updated: '2019-11-22 16:54:23'
tags: [python]
permalink: /articles/2019/09/30/1569829864269.html
---
## 一、Supervisor是什么？

这是一个GitHub上5686 star（截至2019-09-30 13:57:24）的项目，下面给出项目在[GitHub](https://github.com/Supervisor/supervisor)上的定义：

>   Supervisor is a client/server system that allows its users to control a number of processes on UNIX-like operating systems.

翻译：Supervisor是一个客户端/服务器系统，允许其用户控制类似UNIX的操作系统上的许多进程。

简单来说，Supervisor就是一个unix系统上的进程管理工具，它允许程序后台运行，并提供完备的管理功能。

## 二、安装

Supervisor需要使用python进行安装。

> PS: Supervisor现在已经支持Python3啦～！

用pip安装Supervisor:

```shell
pip3 install supervisor
```

## 三、配置

Supervisor查找配置文件的顺序如下（越靠前越优先）：

- 当前目录下的supervisord.conf（./supervisord.conf）
- 当前目录的etc目录下的supervisord.conf (./etc/supervisord.conf)
- 相对于可执行文件supervisord的上一级的etc目录下的supervisord.conf（../etc/supervisord.conf）
- 相对于可执行文件supervisord的上一级的supervisord.conf（../supervisord.conf）

当然，我们也可以直接指定配置文件的位置。我更喜欢这种方式，不容易出错：

```
supervisord -c /etc/supervisord.conf
```

上面只是使用示例，在使用之前，我们需要先创建配置文件。

使用vim在`/etc/`目录下创建`supervisord.conf`文件，并添加如下内容：

```
[unix_http_server]
file=/tmp/supervisor.sock   ; the path to the socket file

[inet_http_server]         ; inet (TCP) server disabled by default
port=0.0.0.0:9001         ; ip_address:port specifier, *:port for all iface
username=your_username              ; default is no username (open server)
password=your_password        ; default is no password (open server)

[supervisord]
logfile=/var/log/supervisord/supervisord.log ; main log file; default $CWD/supervisord.log
logfile_maxbytes=50MB        ; max main logfile bytes b4 rotation; default 50MB
logfile_backups=10           ; # of main logfile backups; 0 means none, default 10
loglevel=info                ; log level; default info; others: debug,warn,trace
pidfile=/var/run/supervisord.pid ; supervisord pidfile; default supervisord.pid
nodaemon=false               ; start in foreground if true; default false
minfds=1024                  ; min. avail startup file descriptors; default 1024
minprocs=200                 ; min. avail process descriptors;default 200
user=root            ; setuid to this UNIX account at startup; recommended if root

[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface

[supervisorctl]
serverurl=unix:///tmp/supervisor.sock ; use a unix:// URL  for a unix socket
prompt=supervisor        ; cmd line prompt (default "supervisor")

[include]
files = /etc/supervisor/conf.d/*.conf
```

这里面配置的基本都是Supervisord本身相关的进程，其他的我用不到的，就没加里面了。配置文件的末尾配置了`include`，表示但凡是存放在`/etc/supervisor/conf.d/`目录下的以`.conf`作为扩展名的文件，都会被作为Supervisord的子配置文件进行加载，我们自己的程序可以在这里配置。

假设我有程序`/root/code/demo/demo.py`，需要它后台运行，可以按如下流程操作：

1. 在`/etc/supervisor/conf.d/`目录下，创建`demo.conf`文件。

```
mkdir /etc/supervisor
mkdir /etc/supervisor/conf.d
cd /etc/supervisor/conf.d/
vim demo.conf
```

2.在文件内写入如下数据：

```
[program:demo_program]
command=python3 demo.py ;启动需要的命令
autostart=true ;是否随Supervisord一起启动
autorestart=true ;程序异常退出后是否自动重启
startsecs=20 ;在程序启动startsecs秒内，没有异常退出的话，就认为成功启动
startretries=3 ;启动失败后，尝试重新启动的次数
user=root ;启动Supervisord进程使用的用户
priority=100 ;启动优先级，优先级越低越优先启动
redirect_stderr=true ;把错误日志重定向到输出的日志中
stdout_logfile=/var/log/supervisord/demo_program.log ;日志保存路径
directory=/root/code/demo/ ;项目路径，就是你执行command时，需要切换到的路径
stdout_logfile_maxbytes=20MB ;输出日志文件大小限制
```

3.保存文件。

## 四、简单使用

配置完成了，我们尝试启动它。

在命令行输入以下命令：

```
supervisord -c /etc/supervisord.conf
```

如果没有报错的话，就是启动成功啦。

我们使用`supervisorctl`连接它看一下，在命令行输入：

```
supervisorctl -c /etc/supervisord.conf
```

成功连接进去，但我们能看到，demo_program启动失败了：

![image.png](https://img.hacpai.com/file/2019/09/image-ce807a8a.png)


为什么鸭？因为我们根本没写demo.py那个脚本啊Orz...

现在我们去把脚本补上：

```
mkdir -p /root/code/demo/
cd /root/code/demo
vim demo.py
```

脚本内容的话，就每隔一秒钟，输出一次当前时间吧：

```python
#coding=utf-8
from datetime import datetime
import time

while True:
    print(datetime.today())
    time.sleep(1)
```

保存脚本。

重新使用`supervisorctl -c /etc/supervisord.conf`连接supervisord，可以看到demo_program仍然没有运行。


我们启动它：

```
start demo_program
```

可能会等的久一点，因为我们设置了观察是否启动成功的时间为20s，不喜欢的话你也可以把它调小。看一下状态，启动成功啦！

![image.png](https://img.hacpai.com/file/2019/09/image-e4fb2c2b.png)

我们可以看一下它的输出日志，是不是真的像我们想象中一样正常运行。先使用Ctrl+D退出supervisorctl，然后在命令行输入：

```
tail -f /var/log/supervisord/demo_program.log
```

![image.png](https://img.hacpai.com/file/2019/09/image-98892cb5.png)


好的，这个程序已经正常运行了。如果想要Supervisor管理新的程序怎么办的？我们先在`/root/code/demo/`中添加`demo2.py`：

```python
#coding=utf-8
from datetime import datetime
import time

while True:
    print(datetime.today(),'这是第二个测试程序!')
    time.sleep(1)
```

同时在`/etc/supervisor/conf.d/`中添加`demo2.conf`：

```
[program:demo2]
command=python3 demo2.py
autostart=true
autorestart=true 
startsecs=5
startretries=3 
user=root 
priority=100 
redirect_stderr=true 
stdout_logfile=/var/log/supervisord/demo2.log 
directory=/root/code/demo/
stdout_logfile_maxbytes=20MB
```

然后连接进supervisord：

```
supervisorctl -c /etc/supervisord.conf
```

输入`update`，supervisord会检查配置文件的变更，并启动新加入的程序：


![image.png](https://img.hacpai.com/file/2019/09/image-2151e11e.png)

## 五、常用命令

在supervisorctl中常用的几个命令：



命令|用途
--|--
stop xxx | 关闭进程
start xxx | 开启进程
status | 查看进程状态
update | 更新配置文件


## 六、web管理界面  
  
相关参数请参考上面的supervisord.conf配置文件，输入相应的主机地址和端口即可。以上面的配置文件为例，假设本地访问，在浏览器中输入[http://localhost:9001](http://localhost:9001)即可。

![image.png](https://img.hacpai.com/file/2019/10/image-0e98aecc.png)


-------------------------

参考资料：

[董伟明 《Python Web开发实战》](http://product.dangdang.com/24029839.html)
