title: 一分钱不花，教你白piao一套自己的云笔记系统
date: '2022-01-04 22:19:36'
updated: '2022-01-04 22:21:54'
tags: [开源工具]
permalink: /articles/2022/01/04/1641305976630.html
---
白piao果然是人类的本质，试问谁能拒绝一套手感优秀、界面美观、功能强大、还不需要花钱的云笔记系统呢？

我理想中的好用的笔记系统应该是这样的：

- 必须支持`Markdown`语言（哪怕只支持`Markdown`一种，别的都不支持，我们也是好朋友~）
- 界面要美观（强是一个版本的事，帅是一辈子的事~）
- 码字体验优秀（界面清爽，没有花里胡哨，支持`Markdown`预览，最好是`所见即所得`的`即时预览`功能）
- PC端应该是跨平台的，即 `Windows`/`Macos`/`Linux`都支持
- 移动端也应该`IOS`和`Android`都支持
- 应该有同步机制，保证多端（PC端和移动端）、多设备的数据是互通的，可以随时接力工作，也就是云服务（另外别限制终端数量，不然会非常难受）
- 云服务应该可靠，不需要为服务商随时跑路担心
- 支持搜索，方便在笔记比较多时快速找到自己想要的内容
- 最好支持笔记的版本管理
- 可以导出笔记为`PDF`
- 能白piao就白piao，不要多花钱

我之前使用的旧方案是 `Typora`+`GitHub`,大致是这样的：

- `Typora`作为编辑器
  - 支持`Markdown`语言
  - 界面美观
  - 码字体验优秀
  - `Windows`/`Macos`/`Linux`都支持
  - 支持搜索
  - 可以导出笔记为`PDF`等其他格式
- `GitHub`作为云服务
  - 移动端直接使用浏览器访问`GitHub`实现
  - 通过定时任务同步`GitHub`仓库
  - `GitHub`作为云服务应该算可靠吧...反正我是不太担心它跑路(doge)
  - 使用`Git`天生具备了版本管理的优势
- 全免费~

这套方案已经使用了一年多了，用起来还算挺舒服的，但是不得不说，还是有些瑕疵的：

- `Typora`虽然支持搜索，但是它的搜索功能好像有`Bug`，搜索结果不全，基本跟摆设一样
- 使用浏览器访问`GitHub`，确实实现了移动端的云笔记联通，但讲真的确实不怎么方便
- 笔记中使用的图片，是保存到笔记所在目录下的隐藏文件夹中的，在笔记中使用相对路径引用，并且会随着笔记一起同步到`GitHub`，保证了不论在本地，还是在`GitHub`上直接阅读，图片都能够正常显示。但是，如果想把笔记分享给别人、或者发表到其他地方就不是很方便了，因为图片链接不是图床生成的外链，图片无法正常显示。

于是，我打算优化一些我的笔记系统，于是就有了这篇文章。这套新的系统能够满足我对好用的笔记系统的全部预期的同时，也解决了刚才说的老方案中存在的问题。

现在开始，教你不花一分钱，使用`Joplin`+`Typora`+`PicGo`+`Gitee`+`OneDrive`搭建自己的免费云笔记系统。

## 一、需要的工具和承担的角色

- `Joplin`
  - 简介：一款免费的开源桌面和移动笔记应用程序，支持 `Windows`/`Macos`/`Linux`/`IOS`/`Android`全平台
  - 定位：笔记管理工具，所有的笔记都由`Joplin`组织和管理，浏览、搜索、同步控制都可以在`Joplin`上完成。
- `Typora`
  - 简介：一款轻量级的、简单而优雅的、所见即所得的`Markdown`编辑器，支持 `Windows`/`Macos`/`Linux`。
  - 定位：笔记编辑工具，用它来替代`Joplin`的编辑功能会使得码字的体验更上一层楼。另外，我也很喜欢`Typora`的导出功能，`Typora`的`Markdown`导出为`PDF`或`Docx`的效果十分出色。
- `PicGo`
  - 简介：一个用于快速上传图片并获取图片 `URL` 链接的工具，支持 `Windows`/`Macos`/`Linux`。
  - 定位：图片上传工具，图床客户端。有了图床，就可以自由转发笔记，不需要担心图片无法显示了。
- `Gitee`
  - 简介：基于Git的代码托管和协作开发平台，用个比较好理解的方式去比喻它：“国产的`GitHub`”。`GitHub`能做到的事情，它大部分都可以做到。
  - 定位：虽然是代码仓库，但我们这里把仓库作为图片仓库来使用，在我们这套体系里给它的定位是图床服务端。注意，`Gitee`最大只支持`1M`图片的直链显示，所以大于`1M`的图片就无解了。`1M`的大小限制对我来说是足够的，如果经常上传大图片的话可以考虑搭配七牛云之类的服务一起使用。另外这里选择`Gitee`而非`GitHub`的原因是，`Gitee`是国内的服务，网络状况会更加稳定一些。
- 坚果云/`OneDrive`
  - 简介：OneDrive是微软公司所推出的网络硬盘及云端服务，免费版容量5GB。坚果云是上海亦存网络科技有限公司创办的一家云端储存平台，免费版每个月享有上传流量1GB,下载流量3GB。
  - 定位：笔记云服务，`Joplin`可以将笔记加密上传到云服务空间中，也可以从指定的云服务空间下载加密的笔记并解密。配置好后，这个过程是自动化的。

## 二、工具安装和配置

### 1\. `Joplin`

`Joplin` 的官网在这里：https://joplinapp.org/

PC端支持 `Windows`/`Macos`/`Linux`。。

下载链接为： https://joplinapp.org/download/

`Android`端可以先看看自家手机厂商的应用商店里是否存在`Joplin`客户端，如果没有的话再通过如下两种途径之一进行获取：

- 如果已经安装了`Google Play`商店，可以直接从`Google Play`商店下载安装
- 如果无法安装`Google Play`商店，也可以直接从[f-droid](https://www.f-droid.org/) (https://www.f-droid.org/) 的网页端下载

`IOS`端直接从 `App Store` 下载安装。

### 2\. `PicGo`

`PicGo` 的说明文档可以看这里：https://picgo.github.io/PicGo-Doc/zh/guide/

具体安装说明参见 [https://picgo.github.io/PicGo-Doc/zh/guide/#下载安装](https://picgo.github.io/PicGo-Doc/zh/guide/#%E4%B8%8B%E8%BD%BD%E5%AE%89%E8%A3%85)

![image-20220103151131569](https://b3logfile.com/file/2022/01/solo-fetchupload-5608762033861000878-c3766c9c.png)

### 3\. 注册`Gitee`，并创建图床仓库

如果还没有`Gitee`账号的话，可以先到 `Gitee` 官网注册一个。官网地址：https://gitee.com/

注册完成之后，需要在 `Gitee` 上创建一个仓库用于存放图片。为了更好地进行分享，我们需要创建一个公开的仓库。

进入这个页面创建仓库： https://gitee.com/projects/new

![image-20220103155320517](https://b3logfile.com/file/2022/01/solo-fetchupload-3351294864583604504-838d1277.png)

创建完仓库后，还需要创建一个`Token`，让 `PicGo` 有权限操作 `Gitee` 仓库。

私人令牌(`Token`)可以通过 `Gitee` -> 设置 -> 安全设置 -\> 私人令牌 进行管理，在管理页面点击 `+生成新令牌` 按钮即可创建新的 `Token`。

也可以通过这个链接直接快速抵达私人令牌管理页面：[https://gitee.com/profile/personal\_access\_tokens](https://gitee.com/profile/personal_access_tokens)

![image-20220103160043832](https://b3logfile.com/file/2022/01/solo-fetchupload-2519498512930440667-71705e1e.png)

没有必要把所有的权限都给`PicGo`，只给你认为需要给的就行。如果你不确定哪些权限需要给，也可以参考我这个，我这个权限也是冗余的，只是去掉了一些比较敏感的权限，其他我不确定的都保留了。

![image-20220103160236814](https://b3logfile.com/file/2022/01/solo-fetchupload-3023387332561109335-688e3147.png)

点击提交后即可生成`Token`，注意，生成的`Token`请保存下来备用，它只会显示一次，如果你丢失了就需要重新生成。

### 4\. 在 `PicGo` 里安装并配置 `Gitee`

`PicGo` 默认不提供 `Gitee` 图床功能（对应的有`GitHub`，但是对于国内的网络环境来说，还是`Gitee`体验更好一些），但不用慌，它可以通过安装插件的方式支持`Gitee`。

打开`PicGo`的设置页面 -\> 插件管理，搜索并安装 `Gitee` 插件即可。可能会搜索出多个插件，理论上装那个都行（我没测试），我安装的是第一个。

![image-20220103160923108](https://b3logfile.com/file/2022/01/solo-fetchupload-2388888591225142305-1b4ccc7c.png)

安装完成之后，在设置页面 -\> 图床设置里面，就能够找到`Gitee图床`选项了。在使用之前，还需要对图床进行一下配置。

![image-20220103161525942](https://b3logfile.com/file/2022/01/solo-fetchupload-866959498860162229-38aff12f.png)

### 5\. `Typora`

`Typora` 是我用过的体验最好的 `MarkDown` 编辑器，界面非常漂亮，码字的手感也相当 Nice。

我最开始接触`Typora`的时候，`Typora`还是测试版本（即 v1.0以前的版本），现在已经推出正式版了。

`Typora`的测试版本是免费的，如果不想花钱的话可以去找 v1.0以前的测试版本软件使用，完全够用了，我目前用的就是测试版本的，版本号 0.11.18 .

正式版本的收费价格当前为 $14.99, 约合人民币 95.27 元，想要体验最新版本的`Typora`或者不差钱的朋友，也可以考虑支持一下。

`Typora`的下载链接，正式版本和测试版本都有：https://typora.io/releases/all

`正式版本`在这里下载：

![image-20220103165017523](https://b3logfile.com/file/2022/01/solo-fetchupload-6105491195382723845-3d19f2d5.png)

`测试版本`在这里下载：

![image-20220103165147586](https://b3logfile.com/file/2022/01/solo-fetchupload-5028803070546083562-1fe429ac.png)

### 6\. 在 `Typora` 里设置自动使用 `PicGo` 上传图片到图床

打开 `Typora` 的设置页面，进行如下设置：

![image-20220103162907029](https://gitee.com/AaronJny/public_images/raw/master/image-20220103162907029.png)

如果你之前对`Gitee`、`PicGo`的设置都正确的话，到这里，图床服务已经可以正常使用了，可以点击页面上的 `验证图片上传选项` 按钮进行测试：

![image-20220103163400215](https://b3logfile.com/file/2022/01/solo-fetchupload-109010419104439108-4ae51bdd.png)

如果你看到这个页面，就说明你的设置可能存在问题，请重新检查你上面的各项配置是否存在问题（当然，我这里失败了是因为图片已经上传过了……）正常情况下，这里应该是个成功的提示。

至此，你在 `Typora` 里写文章时，如果你尝试将粘贴板里的图片粘贴到文章里时，`Typora` 会自动调用 `PicGo` 上传图片到图床，并将返回的图片外链插入到文章中，就像这样：

![image-20220103163805186](https://gitee.com/AaronJny/public_images/raw/master/image-20220103163805186.png)

### 7\. 设置 `Typora` 作为 `Joplin` 的外部编辑器

进入 `Joplin` 的设置页面 -\> 通用选项，进行配置。

![image-20220103170558874](https://gitee.com/AaronJny/public_images/raw/master/image-20220103170558874.png)

当想使用`Typora`编辑笔记时，只需要选中对应笔记，右键，并选择`在外部编辑器中编辑`即可。

当然，也可以使用快捷键来完成这个操作，选中对应笔记，然后按下 `Ctrl`+`E`即可。

![image-20220103215311135](https://gitee.com/AaronJny/public_images/raw/master/image-20220103215311135.png)

### 8\. `Joplin` \+ `OneDrive` 实现云同步

打开 `Joplin` 设置页面 -> 同步 -\> 打开同步向导。

![image-20220103173309406](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173309406.png)

在弹出的页面中选择 `OneDrive`:

![image-20220103173440668](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173440668.png)

点击弹出来的链接：

![image-20220103173512870](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173512870.png)

在跳转到的窗口中登录你的 `MicroSoft` 账号：

![image-20220103173712800](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173712800.png)

允许 `Joplin` 访问信息：

![image-20220103173807315](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173807315.png)

授权成功~

![image-20220103173907484](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173907484.png)

![image-20220103173945468](https://gitee.com/AaronJny/public_images/raw/master/image-20220103173945468.png)

已经完成了，如果我们这个时候登录进 `OneDrive`，还能够看到 `Joplin` 同步上来的文件。

![image-20220103174257141](https://gitee.com/AaronJny/public_images/raw/master/image-20220103174257141.png)

`OneDrive` 的免费容量为 5GB，作为笔记同步/备份应该已经能满足大部分人的需求了。

如果你需要更大的空间，可以考虑：

- 在 `OneDrive` 上开通更大的空间 （付费）
- 如果你有坚果云的会员，也可以借助 `WebDAV` 将坚果云作为 `Joplin` 的云空间 （付费）
- 如果你有`NAS`服务（比如我就在家自建了`NAS`），可以考虑在`NAS`上自建 `Joplin Server` 或者 `WebDAV` （需要自行考虑运维和数据安全的问题）

对于大部分人来说，直接使用免费版的`OneDrive`或者坚果云可能是最合适的选择，空间基本是够用的，并且不需要操心运维问题。

### 9\. `Joplin` 笔记加密

如果你对 `OneDrive` 很放心的话，那你可以不做这一步。否则，可以考虑对笔记进行加密，这样同步到 `OneDrive` 上的数据都是加密后的，没有密码的话，哪怕 `OneDrive` 上的数据泄露了，别人也无法获得你的明文笔记。

请注意，如果你决定对笔记进行加密的话，请务必保管好加密密码，如果该密码丢失，你将无法恢复你的加密笔记！！！

在 `Joplin` 设置页面 -> 加密 -\> 管理主密码 中，设置你的加密密码：

![image-20220103174741156](https://gitee.com/AaronJny/public_images/raw/master/image-20220103174741156.png)

设置好密码之后，启用加密：

![image-20220103175009083](https://gitee.com/AaronJny/public_images/raw/master/image-20220103175009083.png)

![image-20220103175051094](https://gitee.com/AaronJny/public_images/raw/master/image-20220103175051094.png)

启用加密后，`OneDrive`上的未加密信息将被删除，笔记将被加密后重新上传。

### 10\. `Joplin` 的网页剪辑器

`Joplin` 的网页剪辑器类似于印象笔记的“剪藏”功能，可以简单快速的将网页内容导入到笔记中。

在 `Joplin` 设置页面 -\> 网页剪辑器 中能够看到使用说明，按照步骤安装设置即可。

![image-20220103181527827](https://gitee.com/AaronJny/public_images/raw/master/image-20220103181527827.png)

随便打开一个网页，测试一下剪辑效果：

![image-20220103182441994](https://gitee.com/AaronJny/public_images/raw/master/image-20220103182441994.png)

![image-20220103182655948](https://gitee.com/AaronJny/public_images/raw/master/image-20220103182655948.png)

更多的功能小伙伴们就自己测试吧~

### 11.`Typora` CSS 美化

如果觉得 `Typora` 的渲染效果还不够好看，我们还可以通过安装新的主题来美化它。

你可以从这里找到很多 `Typora` 的主题：

https://theme.typora.io/

![image-20220103223913954](https://gitee.com/AaronJny/public_images/raw/master/image-20220103223913954.png)

从这些主题里面选一个自己喜欢的，我觉得这个就不错：https://theme.typora.io/theme/Drake/

![image-20220103194329667](https://gitee.com/AaronJny/public_images/raw/master/image-20220103194329667.png)

点击 `Download` 按钮，下载主题文件。下载下来的是一个zip文件，先解压它，解压后文件内容如下：

![image-20220103194506422](https://gitee.com/AaronJny/public_images/raw/master/image-20220103194506422.png)

这里面的每一个css文件，都是一个主题，他们大体上是相同的，主要是在细节方面有些微区别。选一个自己最喜欢的就好，比如我想用 `drake-vue.css`，那么我需要把 `drake` 文件夹、`img` 文件夹、`drake-vue.css` 文件复制到 `Typora` 的主题目录下。

那么问题来了？`Typora` 的主题目录在哪儿？

打开 `Typora` 设置页面 -> 外观 -> 主题 -\> 打开主题文件夹 ，主题文件夹就会自动弹出来：

![image-20220103194933910](https://gitee.com/AaronJny/public_images/raw/master/image-20220103194933910.png)

把对应的文件直接粘贴进去即可。

这个时候我们在`Typora`的主题列表里面仍然是找不到刚才导入的主题的，解决方案也很简单。先完全退出 `Typora` 程序，然后再重新打开，就能找到并切换新导入的主题了。

### 12\. `Joplin` CSS 美化

`Typora`的主题文件在`Joplin`下也是可以使用的。

打开 `Joplin` 设置页面 -\> 通用选项，能够看到笔记和设置的存放位置，比如我的存放位置是这个：

![image-20220103195414307](https://gitee.com/AaronJny/public_images/raw/master/image-20220103195414307.png)

打开这个文件夹，将刚才复制到 `Typora` 主题目录里的 `drake` 文件夹、`img` 文件夹、`drake-vue.css` 文件也复制一份到这个文件夹下，并将`drake-vue.css`文件重命名为`userstyle.css`即可。

为了使主题生效，也需要先完全退出`Joplin`程序，然后重新启动它，新的主题会自动应用。

---

**关于我**

某以Python作为主要语言的技术爱好者，ACM-ICPC破铜烂铁选手。

某喜欢分享、又菜的一批的、喜欢搞爬虫和算法的弱鸡。

某不知名、正在努力成长中的技术博主。

CSDN: [https://blog.csdn.net/aaronjny](https://blog.csdn.net/aaronjny)

GitHub: [https://github.com/AaronJny](https://github.com/AaronJny)

知乎: [https://www.zhihu.com/people/aaronjny](https://www.zhihu.com/people/aaronjny)

微信公众号: `技术小白成长日记`

**加油，共勉！**

