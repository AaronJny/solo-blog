title: 有趣的深度学习——使用TensorFlow 2.0实现图片神经风格迁移
date: '2020-03-15 15:11:41'
updated: '2020-03-15 15:23:16'
tags: [tensorflow, 深度学习, 风格迁移]
permalink: /articles/2020/03/15/1584256301112.html
---
# 前言

这也是一个重写的项目，之前用Python 2.7 + TensorFlow 1.4写的图片神经风格迁移的项目（[TensorFlow 练手项目三：使用 VGG19 迁移学习实现图像风格迁移](https://blog.csdn.net/aaronjny/article/details/79681080)）直到现在还有很多朋友问我相关问题，毕竟环境太过古老，如今很难顺利跑起来，可能要做不少兼容性的调整（除非照装一样的环境……）。于是，我抽时间用TensorFlow 2.0重写了一下。

先做一下简单演示，风格图片统一使用《星夜》：

![style.jpg](https://img.hacpai.com/file/2020/03/style-4dff8a0d.jpg)


示例1：

输入图片

![city.jpg](https://img.hacpai.com/file/2020/03/city-e3840660.jpg)

输出图片

![citygen.jpg](https://img.hacpai.com/file/2020/03/citygen-40188e4c.jpg)

示例2：

输入图片

![dog.jpg](https://img.hacpai.com/file/2020/03/dog-524b8bfb.jpg)

输出图片

![doggen.jpg](https://img.hacpai.com/file/2020/03/doggen-c740ce28.jpg)


项目 GitHub 地址：

[DeepLearningExamples/tf2-neural-style-transfer](https://github.com/AaronJny/DeepLearningExamples/tree/master/tf2-neural-style-transfer) : https://github.com/AaronJny/DeepLearningExamples/tree/master/tf2-neural-style-transfer


# 代码解读

这是一个重写项目，原理上和[TensorFlow 练手项目三：使用 VGG19 迁移学习实现图像风格迁移](https://blog.csdn.net/aaronjny/article/details/79681080)没有任何区别，可以直接参考原博文了解细节。只是部分细节上有所差异，我会分别进行说明。公式原理方面请参考老博文，就不赘述了。

1.迁移学习

项目仍然使用在imagenet上预训练的vgg19网络做迁移学习。区别在于，本次我们直接使用tf.keras.applications模块加载预训练的vgg19网络，更加方便。

2.进度提示

为了方便观察训练进度，使用tqdm做了进度提示，并实时输出最新的loss。下面是一次执行的示例：

```
Epoch 1/20: 100%|██████████| 100/100 [00:09<00:00, 10.37it/s, loss=22066.4688]
Epoch 2/20: 100%|██████████| 100/100 [00:07<00:00, 13.09it/s, loss=12479.9658]
Epoch 3/20: 100%|██████████| 100/100 [00:07<00:00, 13.06it/s, loss=9065.9258]
Epoch 4/20: 100%|██████████| 100/100 [00:07<00:00, 13.06it/s, loss=6993.3652]
Epoch 5/20: 100%|██████████| 100/100 [00:07<00:00, 13.02it/s, loss=5558.0947]
Epoch 6/20: 100%|██████████| 100/100 [00:07<00:00, 13.03it/s, loss=4526.5439]
Epoch 7/20: 100%|██████████| 100/100 [00:07<00:00, 13.01it/s, loss=3777.7947]
Epoch 8/20: 100%|██████████| 100/100 [00:07<00:00, 13.00it/s, loss=3228.8064]
Epoch 9/20: 100%|██████████| 100/100 [00:07<00:00, 12.98it/s, loss=2821.5425]
Epoch 10/20: 100%|██████████| 100/100 [00:07<00:00, 12.98it/s, loss=2515.5208]
Epoch 11/20: 100%|██████████| 100/100 [00:07<00:00, 12.97it/s, loss=2278.1858]
Epoch 12/20: 100%|██████████| 100/100 [00:07<00:00, 12.96it/s, loss=2090.5942]
Epoch 13/20: 100%|██████████| 100/100 [00:07<00:00, 12.95it/s, loss=1939.2296]
Epoch 14/20: 100%|██████████| 100/100 [00:07<00:00, 12.95it/s, loss=1813.9688]
Epoch 15/20: 100%|██████████| 100/100 [00:07<00:00, 12.94it/s, loss=1708.0551]
Epoch 16/20: 100%|██████████| 100/100 [00:07<00:00, 12.93it/s, loss=1628.9713]
Epoch 17/20: 100%|██████████| 100/100 [00:07<00:00, 12.93it/s, loss=1545.6821]
Epoch 18/20: 100%|██████████| 100/100 [00:07<00:00, 12.93it/s, loss=1917.6001]
Epoch 19/20: 100%|██████████| 100/100 [00:07<00:00, 12.91it/s, loss=1416.0177]
Epoch 20/20: 100%|██████████| 100/100 [00:07<00:00, 12.91it/s, loss=1359.5453]

Process finished with exit code 0

```

3.加速计算

TensorFlow 2.0 默认使用动态图模式，性能上还是有影响的。所以在单次迭代过程中，使用了`tf.function`利用AutoGraph技术，将迭代过程构造成静态图，加速计算。经测试，在本任务中，不使用`tf.function`训练花费的时间约为使用`tf.function`的两倍。

我的计算设备为GTX 1060，共训练20个epoch，每个epoch训练100次。单个epoch训练约花费7秒。

4.学习率

为了快速降低loss，且我只训练20个epoch，所以选择了比较大的学习率。我不要求loss足够低，生成的图片满意就行，在此学习率下训练20个epoch还不至于出现在局部最优解周围`秘技*反复横跳`的情况，但继续训练下去应该会遇到此问题。如果想要把loss降到足够低，可以在增大训练epoch数的同时，选择较小的学习率，或者使用学习率衰减。但需要明白，这么做需要花费更多的时间，我觉得在这个任务上是没有必要的。

# 使用说明

下面说明如何使用此项目，快速开始体验。

我的开发环境是Python 3.7，通过Anaconda安装的，所以下面指令中的python和pip请酌情替换成python3和pip3。

1.clone 项目：

```git clone https://github.com/AaronJny/DeepLearningExamples.git```


2.切换到子项目根目录：


```cd DeepLearningExamples/tf2-neural-style-transfer```


3.安装依赖环境：

```pip install -r requirements.txt```

4.根据个人需求，修改`settings.py`中的配置参数。

5.运行训练脚本：

```python train.py```

运行成功则会输出训练进度，训练完成后在输出目录（默认`./output`）下能看到生成的图片，默认每个epoch保存一次生成的图片。

下面给出一次训练过程中生成的20张图片，它们直观地展示了神经风格迁移的过程。在这渐进式的过程中，观察两张相邻epoch的图片时，不细看很难看出两张图片的区别。但如果直接对比第一张生成图片和最后一张，感受还是挺明显的：

Epoch 1:

![1.jpg](https://img.hacpai.com/file/2020/03/1-1d9c9833.jpg)

Epoch 2:

![2.jpg](https://img.hacpai.com/file/2020/03/2-e89e2e5e.jpg)

Epoch 3:

![3.jpg](https://img.hacpai.com/file/2020/03/3-19ff4989.jpg)

Epoch 4:

![4.jpg](https://img.hacpai.com/file/2020/03/4-4006e25f.jpg)

Epoch 5:

![5.jpg](https://img.hacpai.com/file/2020/03/5-feddee51.jpg)


Epoch 6:

![6.jpg](https://img.hacpai.com/file/2020/03/6-d9352ff0.jpg)


Epoch 7:

![7.jpg](https://img.hacpai.com/file/2020/03/7-d84a7aca.jpg)


Epoch 8:

![8.jpg](https://img.hacpai.com/file/2020/03/8-b2828501.jpg)


Epoch 9:

![9.jpg](https://img.hacpai.com/file/2020/03/9-75bfad75.jpg)

Epoch 10:

![10.jpg](https://img.hacpai.com/file/2020/03/10-9aea503d.jpg)


Epoch 11:

![11.jpg](https://img.hacpai.com/file/2020/03/11-1cda3715.jpg)


Epoch 12:

![12.jpg](https://img.hacpai.com/file/2020/03/12-93f4bf70.jpg)


Epoch 13:

![13.jpg](https://img.hacpai.com/file/2020/03/13-4e9337af.jpg)


Epoch 14:

![14.jpg](https://img.hacpai.com/file/2020/03/14-4ecca98b.jpg)


Epoch 15:

![15.jpg](https://img.hacpai.com/file/2020/03/15-317a0fee.jpg)


Epoch 16:

![16.jpg](https://img.hacpai.com/file/2020/03/16-5c6372ec.jpg)


Epoch 17:

![17.jpg](https://img.hacpai.com/file/2020/03/17-411f96be.jpg)


Epoch 18:

![18.jpg](https://img.hacpai.com/file/2020/03/18-e87cf2c4.jpg)

Epoch 19:

![19.jpg](https://img.hacpai.com/file/2020/03/19-bae928c5.jpg)

Epoch 20:

![20.jpg](https://img.hacpai.com/file/2020/03/20-a3685430.jpg)


# 结语

好了，以上就是这篇文章的全部内容，感谢您的阅读～

如果你喜欢这篇文章的话，麻烦给点个赞呗 ～谢谢大佬 ～

文中如有错漏之处，还请大佬们指正哈 ～



