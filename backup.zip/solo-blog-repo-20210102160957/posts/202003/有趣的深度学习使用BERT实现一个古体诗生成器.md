title: 有趣的深度学习——使用 BERT 实现一个古体诗生成器
date: '2020-03-11 18:38:33'
updated: '2020-03-11 18:38:33'
tags: [keras, 深度学习, 神经网络]
permalink: /articles/2020/03/11/1583923113887.html
---
# 前言

前阵子使用RNN写了个古体诗生成器（[有趣的深度学习——使用TensorFlow 2.0 + RNN 实现一个古体诗生成器](https://blog.csdn.net/aaronjny/article/details/103806954)）的NLP小Demo玩玩。而现在说到NLP，就很难绕开Transformers系列模型，譬如BERT、GPT-2、RoBERTa、ALBERT、XLNet等等。Transformers系列模型不断刷新着NLP任务得分记录，在绝大多数任务下都远胜于传统的、基于RNN的NLP任务。

那么，既然之前用RNN写了个古体诗生成器，我们不妨也用BERT写一个吧，正好对比一下效果。

# 解读

代码结构和功能与[有趣的深度学习——使用TensorFlow 2.0 + RNN 实现一个古体诗生成器](https://blog.csdn.net/aaronjny/article/details/103806954)(https://blog.csdn.net/aaronjny/article/details/103806954)基本上相同，只是将模型从RNN换成了BERT，注释也很详细，感觉没有解读的必要了。

对照着这两份文档就能搞清楚：

基于RNN的模型的详细文档：[使用TensorFlow 2.0 + RNN 实现一个古体诗生成器](https://blog.csdn.net/aaronjny/article/details/103806954)

基于BERT模型的项目源码（即本项目的源码）：[DeepLearningExamples/keras-bert-poetry-generator](https://github.com/AaronJny/DeepLearningExamples/tree/master/keras-bert-poetry-generator)

# 演示

随机生成一首古体诗：

```
不见山头寺，唯闻竹下僧。
白云生寺远，青壁入山深。
夜宿高楼月，秋眠白阁钟。
不缘山下路，何事见僧踪。
```

```
千里彩云千里别，再来还访玉京师。
三年不负青云志，此地终须见汝时。
```

续写一首古体诗（以"床前明月光，"为例）：

```
床前明月光，无端出曙寒。
夜来应不寐，头白露沾袍。
```

```
床前明月光，不见到天涯。
寂寞海云外，寥寥孤烛前。
```

随机生成一首藏头诗（以"海阔天空"为例）：

```
海燕朝朝去，
阔鸥还远居。
天寒疑水势，
空见见鱼行。
```

```
海上苍须插锦鳞，
阔无心计似文君。
天涯本是无心物，
空解将人学钓鳌。
```

BERT 模型使用的是[苏剑林](https://github.com/bojone)大佬封装的 [bert4keras](https://github.com/bojone/bert4keras)，开发过程中参考了 bert4keras 的 [demo](https://github.com/bojone/bert4keras/tree/master/examples)。

模型参数使用的是 Google 官方在中文语料上的预训练权重 [BERT-Base, Chinese](https://github.com/google-research/bert#pre-trained-models)，下载地址为 [https://storage.googleapis.com/bert_models/2018_11_03/chinese_L-12_H-768_A-12.zip](https://storage.googleapis.com/bert_models/2018_11_03/chinese_L-12_H-768_A-12.zip)

# 分析

对比可以发现，预训练的BERT模型在此任务下确实表现良好，远胜于RNN模型。模型在简单的迭代后，很快就能生成还算不错的内容。仔细观察输出的内容，可以发现，在大部分语句中，模型是遵守仄起平收的（一个还算客观的评价标准？）。然后主观上来看，意境上也要稍优于RNN模型？（个人看法，这里就见仁见智啦。虽然严格来说，都是基于概率统计的生搬硬凑……）


# 结语

嘛，就目前来看，Transformers系列模型是大势所趋咯。作为预训练的模型，对于在小公司工作、或个人兴趣开发者来说，真的是个很好的消息。因为你不需要准备一大堆数据，然后在一大批昂贵的GPU、TPU设备上训练长达数周乃至数月的时间，只需要下载某个大公司（Google、华为等）花费较大代价训练好的预训练模型数据，经过简单的fine-tune，即可在你要处理的NLP任务上取得较好的结果，节省大量的时间和资金。

当然啦，如果你的任务追求极致，那就另说啦。

如果你喜欢这篇文章的话，麻烦给点个赞呗～谢谢大佬～

文中如有错漏之处，还请大佬们指正哈～

